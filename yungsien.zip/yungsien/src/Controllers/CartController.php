<?php
declare(strict_types=1);

namespace VantageMarket\Controllers;

use VantageMarket\Services\SessionManager;
use VantageMarket\Services\CartRepository;
use VantageMarket\Services\ProductStockSubject;

final class CartController
{
    public function __construct(
        private SessionManager $session,
        private CartRepository $cartRepository,
        private ProductStockSubject $stockSubject // Injected for Observer Pattern
    ) {}

    private function getActiveCartId(): int {
        $this->session->start();
        
        // 1. If logged in, get the user's cart
        if ($this->session->isAuthenticated()) {
            $userId = $this->session->currentUserId();
            $cart = $this->cartRepository->findOrCreateForUser($userId);
            return $cart->cartId;
        }

        // 2. If guest, use PHP's session ID
        $sessionId = session_id();
        return $this->cartRepository->findOrCreateForSession($sessionId)->cartId; 
    }

    public function viewCart(): void {
        $cartId = $this->getActiveCartId();
        $items = $this->cartRepository->getItems($cartId);
        
        $subtotal = 0.0;
        $totalItems = 0;

        foreach ($items as $item) {
            $lineTotal = $item['price'] * $item['quantity'];
            $subtotal += $lineTotal;
            $totalItems += $item['quantity'];
        }

        include __DIR__ . '/../../views/cart_view.php';
    }

    public function addItem(): void {
        $cartId = $this->getActiveCartId();
        $productId = (int) $_POST['product_id'];
        $quantity = (int) ($_POST['quantity'] ?? 1);

        $this->cartRepository->addItem($cartId, $productId, $quantity);

        // OBSERVER PATTERN: Register cart to watch this product's stock
        $this->stockSubject->attach($productId, $cartId);

        $this->jsonSuccess(['message' => 'Item added to cart']);
    }

    public function removeItem(): void {
        $cartId = $this->getActiveCartId();
        $productId = (int) $_POST['product_id'];

        $this->cartRepository->removeItem($cartId, $productId);
        
        // OBSERVER PATTERN: Unregister cart from watching this product
        $this->stockSubject->detach($productId, $cartId);
        
        $this->jsonSuccess(['message' => 'Item removed']);
    }

    // --- Helper Method ---
    private function jsonSuccess(array $data, int $status = 200): void {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => true, ...$data], JSON_UNESCAPED_UNICODE);
        exit;
    }
}