<?php
// views/cart_view.php
// Variables available from CartController: $items, $subtotal, $totalItems
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shopping Cart — VantageMarket</title>
    <link rel="stylesheet" href="/css/homepage.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <h2 class="mb-4">Your Shopping Cart</h2>

    <div class="row">
        <div class="col-md-8">
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <?php if (empty($items)): ?>
                        <p class="text-muted text-center py-4">Your cart is currently empty.</p>
                    <?php else: ?>
                        <?php foreach ($items as $item): ?>
                            <div class="row mb-3 align-items-center border-bottom pb-3 cart-item-row" data-product-id="<?= htmlspecialchars((string)$item['product_id']) ?>">
                                <div class="col-md-2">
                                    <span class="badge bg-secondary">SKU: <?= htmlspecialchars($item['sku']) ?></span>
                                </div>
                                <div class="col-md-4">
                                    <h5 class="mb-0"><?= htmlspecialchars($item['title']) ?></h5>
                                </div>
                                <div class="col-md-2 text-center">
                                    Qty: <?= (int)$item['quantity'] ?>
                                </div>
                                <div class="col-md-2 text-end fw-bold">
                                    $<?= number_format((float)$item['price'] * (int)$item['quantity'], 2) ?>
                                </div>
                                <div class="col-md-2 text-end">
                                    <button class="btn btn-sm btn-danger remove-item-btn" data-id="<?= htmlspecialchars((string)$item['product_id']) ?>">Remove</button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0">Order Summary</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span>Total Items</span>
                        <span><?= $totalItems ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-3 fw-bold fs-5 border-top pt-2">
                        <span>Subtotal</span>
                        <span>$<?= number_format($subtotal, 2) ?></span>
                    </div>
                    <button class="btn btn-warning w-100 fw-bold" <?= empty($items) ? 'disabled' : '' ?>>
                        Proceed to Checkout
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.remove-item-btn').forEach(button => {
    button.addEventListener('click', async function() {
        const productId = this.getAttribute('data-id');
        
        // Disable button to prevent double-clicks
        this.disabled = true;
        this.innerText = 'Removing...';

        try {
            const formData = new FormData();
            formData.append('product_id', productId);

            const response = await fetch('/cart/remove', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                // Reload the page to update subtotals and the observer system
                window.location.reload();
            } else {
                alert('Failed to remove item.');
                this.disabled = false;
                this.innerText = 'Remove';
            }
        } catch (error) {
            console.error('Error:', error);
            alert('A network error occurred.');
            this.disabled = false;
            this.innerText = 'Remove';
        }
    });
});

window.addEventListener('pageshow', (event) => {
    const isBackForward = performance.getEntriesByType('navigation').some(nav => nav.type === 'back_forward');
    if (event.persisted || isBackForward) {
        window.location.reload();
    }
});
</script>

</body>
</html>