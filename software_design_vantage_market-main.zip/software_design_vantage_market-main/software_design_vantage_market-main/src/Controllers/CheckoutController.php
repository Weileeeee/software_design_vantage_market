<?php

namespace VantageMarket\Controllers;

use Exception;
use PDO;

class CheckoutController
{
    private $db;
    private $session;
    private $cartRepo;

    // We inject the database, session manager, and cart repository explicitly
    public function __construct($db, $session, $cartRepo)
    {
        $this->db = $db;
        $this->session = $session;
        $this->cartRepo = $cartRepo;
    }

    public function index()
    {
        // 1. Ensure user is tracked
        $this->session->start();
        $userId = $this->session->currentUserId();

        // 2. Use session-selected items (from cart page selection) or full cart
        if (!empty($_SESSION['vm_checkout_items'])) {
            $cartItems = $_SESSION['vm_checkout_items'];
        } else {
            $cart = $this->cartRepo->findOrCreateForUser($userId);
            $cartItems = $this->cartRepo->getItems($cart->cartId);
        }

        // 3. If nothing is in the cart, kick them back to the catalog
        if (empty($cartItems)) {
            header("Location: /cart?action=empty");
            exit;
        }

        // 4. Load the visual UI page
        $checkoutError = $_SESSION['checkout_error'] ?? null;
        unset($_SESSION['checkout_error']);

        $promoCodeInput = trim($_SESSION['promo_code'] ?? '');

        $cartSubtotal = 0;
        foreach ($cartItems as $item) {
            $cartSubtotal += ($item['price'] ?? 0) * ($item['quantity'] ?? 0);
        }

        $shippingFee = 5.00;
        $discountPreview = 0.00;
        $discountDetail  = '';

        if ($promoCodeInput !== '') {
            try {
                $stmt = $this->db->prepare(
                    "SELECT * FROM Promotions
                     WHERE code = :code
                       AND is_active = 1
                       AND start_date <= CURDATE()
                       AND expiry_date >= CURDATE()"
                );
                $stmt->execute([':code' => strtoupper($promoCodeInput)]);
                $promo = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($promo) {
                    $eligibleSubtotal = 0;
                    foreach ($cartItems as $item) {
                        if ($item['category_id'] ?? null) {
                            $eligibleSubtotal += ($item['price'] ?? 0) * ($item['quantity'] ?? 0);
                        } else {
                            $eligibleSubtotal += ($item['price'] ?? 0) * ($item['quantity'] ?? 0);
                        }
                    }

                    if ($eligibleSubtotal > 0) {
                        if ($promo['discount_type'] === 'percentage') {
                            $discountPreview = ($eligibleSubtotal + $shippingFee) * ((float)$promo['discount_value'] / 100);
                            $discountDetail = sprintf(
                                '%.0f%% of RM %s',
                                (float)$promo['discount_value'],
                                number_format($eligibleSubtotal + $shippingFee, 2)
                            );
                        } else {
                            $discountPreview = (float)$promo['discount_value'];
                            $discountDetail = 'RM ' . number_format($discountPreview, 2) . ' off';
                        }
                        $discountPreview = min($discountPreview, $eligibleSubtotal + $shippingFee, $cartSubtotal + $shippingFee);
                    }
                }
            } catch (\Throwable $e) {
                // Ignore preview failures; actual checkout will validate.
            }
        }

        $totalPreview = ($cartSubtotal + $shippingFee) - $discountPreview;

        include __DIR__ . '/../../views/checkout_view.php';
    }

    public function processCheckout()
    {
        $this->session->start();
        $userId = $this->session->currentUserId();

        // Use session-selected items if present, else fall back to full cart
        $cart = $this->cartRepo->findOrCreateForUser($userId);
        if (!empty($_SESSION['vm_checkout_items'])) {
            $cartItems = $_SESSION['vm_checkout_items'];
        } else {
            $cartItems = $this->cartRepo->getItems($cart->cartId);
        }

        $promoCode = $_POST['promo_code'] ?? null;

        if (empty($cartItems)) {
            $_SESSION['checkout_error'] = "Your cart is empty. Please select items to order.";
            header("Location: /cart");
            exit;
        }

        try {
            // ==========================================
            // START TRANSACTION: Lock the database state
            // ==========================================
            $this->db->beginTransaction();

            $subtotal = 0;
            $shippingFee = 5.00;
            $validatedItems = [];

            // ------------------------------------------
            // PHASE 1: Inventory Verification & Locking
            // ------------------------------------------
            foreach ($cartItems as $item) {
                // Ensure array keys match your actual cart_items columns
                $productId = $item['product_id'];
                $qty = $item['quantity'];

                // Explicitly lock the product rows using FOR UPDATE
                $stmt = $this->db->prepare("SELECT product_id, category_id, title, price, stock_level FROM Products WHERE product_id = :id FOR UPDATE");
                $stmt->execute(['id' => $productId]);
                $product = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$product) {
                    throw new Exception("Product ID {$productId} is no longer available.");
                }

                if ($product['stock_level'] < $qty) {
                    throw new Exception("Sorry, '{$product['title']}' only has {$product['stock_level']} units left.");
                }

                $itemTotal = $product['price'] * $qty;
                $subtotal += $itemTotal;

                $validatedItems[] = [
                    'product_id'  => $product['product_id'],
                    'category_id' => $product['category_id'],
                    'quantity'    => $qty,
                    'price'       => $product['price']
                ];
            }

            // ------------------------------------------
            // PHASE 2: Promo Code Processing (UC09 Math)
            // ------------------------------------------
            $discountAmount = 0;
            $appliedPromoId = null;

            if (!empty($promoCode)) {
                $promoCode = strtoupper(trim($promoCode));
                $stmt = $this->db->prepare(
                    "SELECT * FROM Promotions
                     WHERE code = :code
                       AND is_active = 1
                       AND start_date <= CURDATE()
                       AND expiry_date >= CURDATE()
                     FOR UPDATE"
                );
                $stmt->execute([':code' => $promoCode]);
                $promo = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$promo) {
                    throw new Exception("Promo code '{$promoCode}' is invalid or expired.");
                }

                if ($promo['usage_limit'] !== null && (int)$promo['usage_count'] >= (int)$promo['usage_limit']) {
                    throw new Exception("Promo code '{$promoCode}' has reached its maximum usage limit.");
                }

                if ($promo['min_spend'] !== null && $subtotal < (float)$promo['min_spend']) {
                    throw new Exception(
                        "Promo code '{$promoCode}' requires a minimum spend of RM " . number_format((float)$promo['min_spend'], 2) . "."
                    );
                }

                $stmt = $this->db->prepare(
                    'SELECT category_id FROM Promo_Category_Exclusions WHERE promo_id = :pid'
                );
                $stmt->execute([':pid' => $promo['promo_id']]);
                $excludedCategories = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'category_id');

                $eligibleSubtotal = 0;
                foreach ($validatedItems as $item) {
                    if (!in_array((int)$item['category_id'], $excludedCategories, true)) {
                        $eligibleSubtotal += $item['price'] * $item['quantity'];
                    }
                }

                if ($eligibleSubtotal > 0) {
                    if ($promo['discount_type'] === 'percentage') {
                        $shippingFee = 5.00;
                        $eligibleAmount = $eligibleSubtotal + $shippingFee;
                        $discountAmount = $eligibleAmount * ((float)$promo['discount_value'] / 100);
                    } else if ($promo['discount_type'] === 'fixed') {
                        $discountAmount = (float)$promo['discount_value'];
                    }
                    $discountAmount = min($discountAmount, $eligibleSubtotal + $shippingFee, $subtotal + $shippingFee);
                }

                $appliedPromoId = (int)$promo['promo_id'];
            }

            $shippingFee = 5.00;
            $finalTotalAmount = ($subtotal + $shippingFee) - $discountAmount;

            // ------------------------------------------
            // PHASE 3: Order Creation (UC06)
            // ------------------------------------------

            // A. Insert the Parent Order
            $stmt = $this->db->prepare(
                "INSERT INTO Orders (user_id, address_id, subtotal, shipping_fee, total_amount, promo_id, status)
                 VALUES (:uid, 1, :sub, :ship, :tot, :pid, 'pending')"
            );
            $stmt->execute([
                'uid'  => $userId,
                'sub'  => $subtotal,
                'ship' => $shippingFee,
                'tot'  => $finalTotalAmount,
                'pid'  => $appliedPromoId,
            ]);
            $newOrderId = $this->db->lastInsertId();

            // B. Insert Child Items & Deduct Physical Stock
            foreach ($validatedItems as $item) {
                // Log the breakdown
                $stmt = $this->db->prepare("INSERT INTO Order_Items (order_id, product_id, quantity, purchased_price) VALUES (:oid, :pid, :qty, :price)");
                $stmt->execute([
                    'oid'   => $newOrderId,
                    'pid'   => $item['product_id'],
                    'qty'   => $item['quantity'],
                    'price' => $item['price']
                ]);

                // Deduct the inventory
                $stmt = $this->db->prepare("UPDATE Products SET stock_level = stock_level - :qty WHERE product_id = :pid");
                $stmt->execute([
                    'qty' => $item['quantity'],
                    'pid' => $item['product_id']
                ]);
            }

            // C. Remove only the ordered items from cart (other items remain)
            foreach ($validatedItems as $item) {
                $this->cartRepo->removeItem($cart->cartId, $item['product_id']);
            }

            if ($appliedPromoId !== null) {
                $this->db->prepare(
                    'UPDATE Promotions SET usage_count = usage_count + 1 WHERE promo_id = :pid'
                )->execute([':pid' => $appliedPromoId]);
            }

            // ==========================================
            // COMMIT TRANSACTION: Save everything safely
            // ==========================================
            $this->db->commit();

            // Clear session checkout state
            unset($_SESSION['vm_checkout_items']);
            $_SESSION['success_message'] = "Order #{$newOrderId} successfully placed!";

            // Redirect to success page
            header("Location: /checkout/success?order=" . $newOrderId);
            exit;
        } catch (Exception $e) {
            // Something broke. Roll back changes to prevent phantom orders
            $this->db->rollBack();

            $_SESSION['checkout_error'] = $e->getMessage();
            if (!empty($promoCode)) {
                $_SESSION['promo_code'] = $promoCode;
            }
            header("Location: /checkout");
            exit;
        }
    }
}
